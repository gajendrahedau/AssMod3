package com.cg.lab1.webservices;

import javax.jws.WebService;

@WebService(endpointInterface="com.cg.lab1.webservices.Product")
public class ProductDB implements Product{

	
	@Override
	public float findPrice(String product) {
		
		String product1=product.toLowerCase();
		float price;
		if(product1.equals("ipad"))
			price=(float) 65234.87;
		else if(product1.equals("mobile"))
			price=(float) 5230.87;
		else if(product1.equals("headphone"))
			price=(float) 280.10;
		else if(product1.equals("adaptor"))
			price=(float) 2300.00;
		else{
			return 0;
		}
		return price;
			
	}

}
